# 📊 Task 4: Dashboard Design – Data Analyst Internship

## 👩‍💻 Created By:
**Vidhi Gupta**

## 🗂 Dataset Used:
- **Name**: Superstore Sales Dataset
- **Source**: Kaggle
- **File**: `train.csv`
- **Total Rows**: 9,994
- **Description**: The dataset contains order-level details of sales transactions, including fields like sales amount, customer segment, region, order date, product categories, and city/state information.

### ❗ Note:
This dataset does **not include** `Profit`, `Quantity`, or `Discount` columns. All dashboard elements are built using available data fields.

---

## 🧰 Tools Used:
- [Power BI Desktop](https://powerbi.microsoft.com/)
- Microsoft PowerPoint
- GitHub

---

## 📈 KPIs (Card Visuals):
- ✅ **Total Sales**
- ✅ **Total Orders** (Unique `Order ID`s)
- ✅ **Total Customers** (Unique `Customer ID`s)

---

## 📊 Visuals in the Dashboard:
- 📍 **Bar Chart**: Sales by Region
- 📆 **Line Chart**: Monthly Sales Trend
- 📚 **Stacked Bar Chart**: Sales by Category and Sub-Category
- 🧭 **Donut Chart**: Sales by Segment
- 🏙️ **Table**: Top 10 Cities by Sales

---

## 🎛 Interactive Filters (Slicers):
- Region
- Category
- Order Date (Between range)

---

## 💡 Key Business Insights:
- **West Region** leads in overall sales.
- **Office Supplies** category has the highest sales volume.
- **Consumer Segment** drives the majority of total sales.
- Sales increase toward year-end, peaking in **November and December**.
- Cities like **Los Angeles** and **New York** are top-performing in terms of revenue.

---

## 📁 Files Included in This Repository:
| File Name                  | Description                               |
|---------------------------|-------------------------------------------|
| `train.csv`               | The original dataset used for analysis    |
| `Sales_Dashboard.pbix`    | Power BI dashboard file                   |
| `Business_Insights_PPT.pptx` | Summary presentation with insights        |
| `README.md`               | This file explaining the task              |

---
